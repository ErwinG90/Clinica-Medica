from flask import Flask

from routes import Paciente, Medico 
from routes.Disponibilidad import disponibilidad_bp
from routes.CitaMedica import cita_medica_bp

app = Flask(__name__)


@app.route('/')
def index():
  return 'Hello from Flask!'


# Blueprint
app.register_blueprint(Paciente.main, url_prefix='/api/pacientes')
app.register_blueprint(Medico.main, url_prefix='/api/medicos')
app.register_blueprint(disponibilidad_bp, url_prefix='/api/disponibilidad')
app.register_blueprint(cita_medica_bp, url_prefix='/api/cita_medica')

app.run(host='0.0.0.0', port=81)
