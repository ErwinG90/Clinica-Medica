from flask import Blueprint, jsonify, request
from models.CitaMedicaModel import CitaMedicaModel

cita_medica_bp = Blueprint("cita_medica", __name__)


@cita_medica_bp.route("/", methods=["GET"])
def get_citas_medicas():
  try:
    cita_medica_model = CitaMedicaModel()
    citas_medicas = cita_medica_model.get_citas_medicas()
    return jsonify(citas_medicas)
  except Exception as ex:
    return jsonify({"msg": str(ex)}), 500


@cita_medica_bp.route('/cambiar/<id_cita_medica>/<nuevo_estado>',
                      methods=['PUT'])
def cambiar_estado_cita(id_cita_medica, nuevo_estado):
  try:
    if request.method == 'PUT':
      modelo = CitaMedicaModel()
      modelo.cambiar_estado_cita_medica(id_cita_medica, nuevo_estado)
      return jsonify(
          {"message": "Estado de cita médica cambiado exitosamente"})
    else:
      return jsonify({"error": "Método no permitido. Se requiere PUT"}), 405
  except Exception as e:
    return jsonify({"error": str(e)}), 500


@cita_medica_bp.route("/add", methods=["POST"])
def add_cita_medica():
  try:
    data = request.get_json()
    if data:
      from models.CitaMedicaModel import CitaMedica

      nueva_cita_medica = CitaMedica(
          rut_medico=data.get("rut_medico"),
          rut_paciente=data.get("rut_paciente"),
          id_disponibilidad=data.get("id_disponibilidad"),
          id_estado=data.get("id_estado"))

      cita_medica_model = CitaMedicaModel()
      cita_medica_model.add_cita_medica(nueva_cita_medica)

      return jsonify({"message": "Cita médica agregada"})
    else:
      return jsonify({"message": "Datos no válidos para la cita médica."}), 400
  except Exception as ex:
    return jsonify({"message": str(ex)}), 500


@cita_medica_bp.route("/citas/<rut_paciente>")
def get_citas_rut(rut_paciente):
  try:
    cita_medica_model = CitaMedicaModel()
    citas = cita_medica_model.get_citas_rut(rut_paciente)
    return jsonify(citas)
  except Exception as ex:
    return jsonify({"msg": str(ex)}), 500
