from flask import Blueprint, jsonify, request
from models.PacienteModel import PacienteModel
from models.entities.Paciente import Paciente
import bcrypt

main = Blueprint("paciente_blueprint", __name__)


@main.route("/")
def getPacientes():
  try:
    pacientes = PacienteModel.getPacientes()
    return jsonify(pacientes)
  except Exception as ex:
    return jsonify({"msg": str(ex)}), 500


@main.route("/<rut>")
def getPacientes_por(rut):
  try:
    pacientes = PacienteModel.getPacientes_rut(rut)
    dicc = pacientes[0]
    email = dicc["email"].replace('"', "")

    return jsonify(email)

  except Exception as ex:
    return jsonify({"msg": str(ex)}), 500


@main.route("/add", methods=['POST'])
def add_paciente():
  try:
    paciente = Paciente(rut=request.json['rut'],
                        nombre=request.json['nombre'],
                        apellido=request.json['apellido'],
                        usuario=request.json['usuario'],
                        email=request.json['email'],
                        contraseña=request.json['contraseña'],
                        direccion=request.json['direccion'],
                        telefono=request.json['telefono'])

    if PacienteModel.digito_verificador(paciente.rut):
      if PacienteModel.add_paciente(paciente):
        return jsonify({"message": "Paciente agregado"})
      else:
        return jsonify({"message": "Error al insertar"}), 500
    else:
      return jsonify({"message": "Rut inválido"}), 500

  except Exception as ex:
    return jsonify({"message": str(ex)}), 500


@main.route('/login', methods=['POST'])
def login():
  try:
    email = request.json['email']
    contraseña = request.json['contraseña']

    paciente = Paciente()
    paciente.email = email
    paciente.contraseña = contraseña

    if PacienteModel.login(paciente):
      return jsonify({"message": "Login success"})
    else:
      return jsonify({"message": "Email y/o contraseña incorrectos"}), 500

  except Exception as ex:
    return jsonify({"message": str(ex)}), 500
