from flask import Blueprint, jsonify, request
from models.DisponibilidadModel import DisponibilidadModel
from models.DisponibilidadModel import Disponibilidad

disponibilidad_bp = Blueprint("disponibilidad", __name__)


@disponibilidad_bp.route("/<rut_medico>")
def get_disponibilidad(rut_medico):
  try:
    disponibilidad_model = DisponibilidadModel()
    disponibilidades = disponibilidad_model.get_disponibilidad(rut_medico)
    return jsonify(disponibilidades)
  except Exception as ex:
    return jsonify({"msg": str(ex)}), 500


@disponibilidad_bp.route('/cambiar/<id_disponibilidad>/<nuevo_estado>',
                         methods=['PUT'])
def cambiar_estado_disponibilidad(id_disponibilidad, nuevo_estado):
  try:
    if request.method == 'PUT':
      disponibilidad_model = DisponibilidadModel()
      disponibilidad_model.cambiar_estado_disponibilidad(
          id_disponibilidad, nuevo_estado)
      return jsonify(
          {"message": "Estado de disponibilidad cambiado exitosamente"})
    else:
      return jsonify({"error": "Método no permitido. Se requiere PUT"}), 405
  except Exception as e:
    return jsonify({"error": str(e)}), 500

@disponibilidad_bp.route("/agregar", methods=["POST"])
def add_disponibilidad():
  try:
      data = request.get_json()

      if data:
          from models.DisponibilidadModel import Disponibilidad

          nueva_disponibilidad = Disponibilidad(
              id_bloque=data.get("id_bloque"),
              rut_medico=data.get("rut_medico"),
              fecha=data.get("fecha"),
              estado=data.get("estado")
          )

          disponibilidad_model = DisponibilidadModel()
          disponibilidad_model.add_disponibilidad(nueva_disponibilidad)

          return jsonify({"message": "Disponibilidad agregada"})
      else:
        return jsonify({"message": "Datos no válidos para la Disponibilidad"}), 400
  except Exception as ex:
    return jsonify({"message": str(ex)}), 500