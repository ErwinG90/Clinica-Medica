from flask import Blueprint, jsonify, request
from models.MedicoModel import MedicoModel
from models.entities.Medico import Medico

main = Blueprint("medico_blueprint", __name__)


@main.route("/")
def getMedicos():
  try:
    medicos = MedicoModel.getMedicos()
    return jsonify(medicos)
  except Exception as ex:
    return jsonify({"msg": str(ex)}), 500


@main.route("/add", methods=['POST'])
def add_medico():
  try:
    medico = Medico(rut=request.json['rut'],
                    sucursal_id=request.json['sucursal_id'],
                    especialidad_id=request.json['especialidad_id'],
                    nombre=request.json['nombre'],
                    apellido=request.json['apellido'],
                    usuario=request.json['usuario'],
                    email=request.json['email'],
                    contraseña=request.json['contraseña'])

    if MedicoModel.digito_verificador(medico.rut):
      if MedicoModel.add_medico(medico):
        return jsonify({"message": "Médico agregado"})
      else:
        return jsonify({"message": "Error al insertar"}), 500
    else:
      return jsonify({"message": "Rut inválido"}), 500
      
  except Exception as ex:
    return jsonify({"message": str(ex)}), 500



@main.route('/login', methods=['POST'])
def login():
  try:
    email = request.json['email']
    contraseña = request.json['contraseña']  

    medico = Medico()
    medico.email = email
    medico.contraseña = contraseña

    if MedicoModel.login(medico):
      return jsonify({"message" : "Login success"})
    else:      
      return jsonify({"message": "Email y/o contraseña incorrectos"}), 500

  except Exception as ex:
    return jsonify({"message": str(ex)}), 500   