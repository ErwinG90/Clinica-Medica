from database.db import get_connection
from models.entities.Medico import Medico
from flask import request

import bcrypt
from itertools import cycle

class MedicoModel:

  @classmethod
  def getMedicos(self):
    try:
      cx = get_connection()
      medicos = []
      with cx.cursor() as cursor:
        cursor.execute(
            'SELECT rut, sucursal_id, especialidad_id, nombre, apellido, usuario, email, contraseña FROM medico'
        )
        resultset = cursor.fetchall()
        for row in resultset:
          medico = Medico(row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7])
          medicos.append(medico.to_JSON())
        cx.close()
        return medicos
    except Exception as ex:
      raise Exception(ex)



  @classmethod
  def digito_verificador(self, rut):
    try:
      rut = rut.replace('.', '').replace('-', '')
      aux = rut[:-1]
      dv = rut[-1:]

      revertido = map(int, reversed(str(aux)))
      factors = cycle(range(2,8))
      s = sum(d * f for d, f in zip(revertido,factors))
      res = (-s)%11

      if str(res) == dv:
        return True
      elif dv=="K" and res==10:
        return True
      else:
        return False
    except Exception as ex:
      raise Exception(ex)

  

  @classmethod
  def add_medico(self, medico):
    try:
      cx = get_connection()
      with cx.cursor() as cursor:
        enc_pwd = bcrypt.hashpw(medico.contraseña.encode("utf-8"), bcrypt.gensalt(10))
        rutv = self.digito_verificador(medico.rut)
        #print(enc_pwd)
        #print(enc_pwd.decode())
        cursor.execute("INSERT INTO medico VALUES(%s, %s, %s, %s, %s, %s, %s, %s)", (
            medico.rut,
            medico.sucursal_id,
            medico.especialidad_id,
            medico.nombre,
            medico.apellido,
            medico.usuario,
            medico.email,
            enc_pwd.decode(),
            
        ))
        affected_rows = cursor.rowcount
        cx.commit()
      cx.close()
      return affected_rows
    except Exception as ex:
      raise Exception(ex)


  @classmethod
  def login(self, medico):
    try:
      cx = get_connection()
      data= request.get_json()
      email = data['email']
      contraseña = data['contraseña'].encode('utf-8')

      with cx.cursor() as cursor:

        query = "SELECT email, contraseña FROM medico WHERE email = 'PARAMETRO'"
        consulta_parametro = query.replace("PARAMETRO",str(medico.email))
        #print("query: "+consulta_parametro)
        cursor.execute(consulta_parametro)

        resultset = cursor.fetchone()

        if resultset and bcrypt.checkpw(contraseña, resultset[1].encode('utf-8')):
          return True
        else:
          return False

    except Exception as ex:
      raise Exception(ex)