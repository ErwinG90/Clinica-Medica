from database.db import get_connection
from models.entities.Paciente import Paciente
from flask import request

import bcrypt
from itertools import cycle


class PacienteModel():

  @classmethod
  def getPacientes(self):
    try:
      cx = get_connection()
      pacientes = []
      with cx.cursor() as cursor:
        cursor.execute(
            'SELECT rut, nombre, apellido, usuario, email, contraseña, direccion, telefono FROM paciente'
        )
        resultset = cursor.fetchall()
        for row in resultset:
          paciente = Paciente(row[0], row[1], row[2], row[3], row[4], row[5],
                              row[6], row[7])
          pacientes.append(paciente.to_JSON())
        cx.close()
        return pacientes
    except Exception as ex:
      raise Exception(ex)

  @classmethod
  def getPacientes_rut(self, rut):
    try:
      cx = get_connection()
      pacientes = []
      with cx.cursor() as cursor:
        cursor.execute('SELECT * FROM paciente WHERE rut = %s', (rut, ))
        resultset = cursor.fetchall()
        for row in resultset:
          paciente = Paciente(row[0], row[1], row[2], row[3], row[4], row[5],
                              row[6])
          pacientes.append(paciente.to_JSON())
        cx.close()
        return pacientes
    except Exception as ex:
      raise Exception(ex)

  @classmethod
  def digito_verificador(self, rut):
    try:
      rut = rut.replace('.', '').replace('-', '')
      aux = rut[:-1]
      dv = rut[-1:]

      revertido = map(int, reversed(str(aux)))
      factors = cycle(range(2, 8))
      s = sum(d * f for d, f in zip(revertido, factors))
      res = (-s) % 11

      if str(res) == dv:
        return True
      elif dv == "K" and res == 10:
        return True
      else:
        return False
    except Exception as ex:
      raise Exception(ex)

  @classmethod
  def add_paciente(self, paciente):
    try:
      cx = get_connection()
      with cx.cursor() as cursor:
        enc_pwd = bcrypt.hashpw(paciente.contraseña.encode("utf-8"),
                                bcrypt.gensalt(10))
        rutv = self.digito_verificador(paciente.rut)
        #print(enc_pwd)
        #print(enc_pwd.decode())
        cursor.execute(
            "INSERT INTO paciente VALUES(%s, %s, %s, %s, %s, %s, %s, %s)",
            (paciente.rut, paciente.nombre,
             paciente.apellido, paciente.usuario, paciente.email,
             enc_pwd.decode(), paciente.direccion, paciente.telefono))
        affected_rows = cursor.rowcount
        cx.commit()
      cx.close()
      return affected_rows
    except Exception as ex:
      raise Exception(ex)

  @classmethod
  def login(self, paciente):
    try:
      cx = get_connection()
      data = request.get_json()
      email = data['email']
      contraseña = data['contraseña'].encode('utf-8')

      with cx.cursor() as cursor:

        query = "SELECT email, contraseña FROM paciente WHERE email = 'PARAMETRO'"
        consulta_parametro = query.replace("PARAMETRO", str(paciente.email))
        #print("query: "+consulta_parametro)
        cursor.execute(consulta_parametro)

        resultset = cursor.fetchone()

        if resultset and bcrypt.checkpw(contraseña,
                                        resultset[1].encode('utf-8')):
          return True
        else:
          return False

    except Exception as ex:
      raise Exception(ex)
