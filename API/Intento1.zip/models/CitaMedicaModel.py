from database.db import get_connection
from models.entities.CitaMedica import CitaMedica
from psycopg2 import Error


class CitaMedicaModel:

  def get_citas_medicas(self):
    try:
      cx = get_connection()
      with cx.cursor() as cursor:
        cursor.execute('''
                SELECT cita_medica.*, disponibilidad.id_bloque, TO_CHAR(disponibilidad.fecha, 'YYYY-MM-DD')
                FROM cita_medica
                INNER JOIN disponibilidad
                ON cita_medica.id_disponibilidad = disponibilidad.id
                ORDER BY disponibilidad.fecha
            ''')
        resultset = cursor.fetchall()
      cx.close()

      citas_medicas = [{
          'id': row[0],
          'rut_medico': row[1],
          'rut_paciente': row[2],
          'id_disponibilidad': row[3],
          'id_estado': row[4],
          'id_bloque': row[5],
          'fecha_disponibilidad': row[6]
      } for row in resultset]
      return citas_medicas
    except Error as ex:
      raise Exception("Error al obtener las citas médicas: " + str(ex))

  def cambiar_estado_cita_medica(self, id_cita_medica, nuevo_estado):
    try:
      cx = get_connection()
      with cx.cursor() as cursor:
        cursor.execute('UPDATE cita_medica SET id_estado = %s WHERE id = %s',
                       (nuevo_estado, id_cita_medica))
        cx.commit()
      cx.close()
    except Error as ex:
      raise Exception("Error al cambiar el estado de la cita médica: " +
                      str(ex))

  def add_cita_medica(self, nueva_cita_medica):
    try:
      cx = get_connection()
      cx.autocommit = False
      with cx.cursor() as cursor:
        cursor.execute(
            'INSERT INTO cita_medica (rut_medico, rut_paciente, id_disponibilidad, id_estado) '
            'VALUES (%s, %s, %s, %s) RETURNING id',
            (nueva_cita_medica.rut_medico, nueva_cita_medica.rut_paciente,
             nueva_cita_medica.id_disponibilidad, nueva_cita_medica.id_estado))

        affected_rows = cursor.rowcount
        cx.commit()
      cx.close()
      return affected_rows
    except Exception as ex:
      raise Exception(ex)

  def get_citas_rut(self, rut_paciente):
    try:
      cx = get_connection()
      with cx.cursor() as cursor:
        cursor.execute(
            '''
                SELECT cita_medica.*, disponibilidad.id_bloque, TO_CHAR(disponibilidad.fecha, 'YYYY-MM-DD')
                FROM cita_medica
                INNER JOIN disponibilidad
                ON cita_medica.id_disponibilidad = disponibilidad.id
                WHERE cita_medica.rut_paciente = %s ORDER BY id
            ''', (rut_paciente, ))
        resultset = cursor.fetchall()
      cx.close()

      citas_medicas = [{
          'id': row[0],
          'rut_medico': row[1],
          'rut_paciente': row[2],
          'id_disponibildad': row[3],
          'id_estado': row[4],
          'id_bloque': row[5],
          'fecha_disponibilidad': row[6]
      } for row in resultset]
      return citas_medicas
    except Error as ex:
      raise Exception("Error al obtener las citas médicas por rut: " + str(ex))
