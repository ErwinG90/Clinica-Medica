class Medico():

  def __init__(self,
               rut=None,
               sucursal_id=None,
               especialidad_id=None,
               nombre=None,
               apellido=None,
               usuario=None,
               email=None,
               contraseña=None):
    self.rut = rut
    self.sucursal_id = sucursal_id
    self.especialidad_id = especialidad_id
    self.nombre = nombre
    self.apellido = apellido
    self.usuario = usuario
    self.email = email
    self.contraseña = contraseña

  def to_JSON(self):
    return {
        'apellido': self.apellido,
        'email': self.email,
        'especialidad': self.especialidad_id,
        'nombre': self.nombre,
        'rut': self.rut,
        'usuario': self.usuario,
        'sucursal': self.sucursal_id
    }
