class CitaMedica:

  def __init__(self,
               id=None,
               rut_medico=None,
               rut_paciente=None,
               id_disponibilidad=None,
               id_estado=None):
    self.id = id
    self.rut_medico = rut_medico
    self.rut_paciente = rut_paciente
    self.id_disponibilidad = id_disponibilidad
    self.id_estado = id_estado

  def to_json(self):
    return {
        'id': self.id,
        'rut_medico': self.rut_medico,
        'rut_paciente': self.rut_paciente,
        'id_disponibilidad': self.id_disponibilidad,
        'id_estado': self.id_estado
    }
