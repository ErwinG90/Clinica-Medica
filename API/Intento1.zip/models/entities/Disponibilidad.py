class Disponibilidad:
  def __init__(self, id=None, id_bloque=None, rut_medico=None, fecha=None, estado=None):
      self.id = id
      self.id_bloque = id_bloque
      self.rut_medico = rut_medico
      self.fecha = fecha
      self.estado = estado

  def to_json(self):
      return {
          'id': self.id,
          'id_bloque': self.id_bloque,
          'rut_medico': self.rut_medico,
          'fecha': self.fecha,
          'estado': self.estado
      }
