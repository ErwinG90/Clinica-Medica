class Paciente():

  def __init__(self,
               rut=None,
               nombre=None,
               apellido=None,
               usuario=None,
               email=None,
               contraseña=None,
               direccion=None,
               telefono=None):
    self.rut = rut
    self.nombre = nombre
    self.apellido = apellido
    self.usuario = usuario
    self.email = email
    self.contraseña = contraseña
    self.direccion = direccion
    self.telefono = telefono

  def to_JSON(self):
    return {
        'apellido': self.apellido,
        'email': self.email,
        'nombre': self.nombre,
        'rut': self.rut,
        'usuario': self.usuario,
        'direccion': self.direccion,
        'telefono': self.telefono
    }
