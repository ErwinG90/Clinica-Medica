from database.db import get_connection
from models.entities.Disponibilidad import Disponibilidad
from psycopg2 import Error


class DisponibilidadModel:

  def get_disponibilidad(self, rut):
    try:
      cx = get_connection()
      with cx.cursor() as cursor:
        cursor.execute(
            'SELECT * FROM disponibilidad WHERE rut_medico = %s ORDER BY fecha',
            (rut, ))
        resultset = cursor.fetchall()
      cx.close()

      disponibilidades = []

      for row in resultset:
        fecha_base_datos = row[3].strftime("%Y-%m-%d")

        disponibilidad = Disponibilidad(row[0], row[1], row[2],
                                        fecha_base_datos, row[4]).to_json()
        disponibilidades.append(disponibilidad)

      return disponibilidades
    except Error as ex:
      raise Exception("Error al obtener la disponibilidad: " + str(ex))

  def cambiar_estado_disponibilidad(self, id_disponibilidad, nuevo_estado):
    try:
      cx = get_connection()
      with cx.cursor() as cursor:
        cursor.execute('UPDATE disponibilidad SET estado = %s WHERE id = %s',
                       (nuevo_estado, id_disponibilidad))
        cx.commit()
      cx.close()
    except Exception as ex:
      raise Exception("Error al cambiar el estado de la disponibilidad: " +
                      str(ex))

  def add_disponibilidad(self, nueva_disponibilidad):
    try:
        cx = get_connection()
        cx.autocommit = False
        with cx.cursor() as cursor:
          cursor.execute(
              'INSERT INTO disponibilidad (id_bloque, rut_medico, fecha, estado) '
              'VALUES (%s, %s, %s, %s) RETURNING *',
              (nueva_disponibilidad.id_bloque, nueva_disponibilidad.rut_medico,
               nueva_disponibilidad.fecha, nueva_disponibilidad.estado))

          affected_rows = cursor.rowcount
          cx.commit()
        cx.close()
        return affected_rows
    except Exception as ex:
      raise Exception(ex)

